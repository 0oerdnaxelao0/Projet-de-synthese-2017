#pragma once
#include "Vecteur2D.h"
#include "Segment.h"
#include <math.h>

Segment::Segment(int couleur, Vecteur2D x, Vecteur2D y) :Forme(couleur), _x(x), _y(y)
{
	if (x == y)
		throw ("Vecteur2Ds �gaux donc pas de segment");
}

Segment::Segment(const Segment & s) :Forme(s), _x(s._x), _y(s._y)
{
}

Segment::~Segment()
{
}

double Segment::getLongueur() const
{
	double res = sqrt(pow((_y.getX() - _x.getX()), 2) + (pow((_y.getY() - _x.getY()), 2)));
	return res;
}

string Segment::Afficher() const
{
	return Forme::Afficher() + "\nSegment : \nX: " + _x.Afficher() + "\nY: " + _y.Afficher() + "\nLongueur : " + to_string(getLongueur());
}

Segment& Segment::Translation(const Vecteur2D & v)
{
	_x.Translation(v);
	_y.Translation(v);
	return *this;
}

Segment& Segment::Rotation(const Vecteur2D & v, double angle)
{
	_x.Rotation(v, angle);
	_y.Rotation(v, angle);
	return *this;
}

Segment& Segment::Homothetie(const Vecteur2D & v, double rapport)
{
	_x.Homothetie(v, rapport);
	_y.Homothetie(v, rapport);
	return *this;
}

void Segment::accepte(Visiteur *v) const
{
	v->visite(this);
}

string Segment::toString() const
{
	return "Segment;" + getCouleur() + ';' + _x.toString() + _y.toString();
}

ostream & operator<<(ostream & o, const Segment & s)
{
	o << s.Afficher();
	return o;
}
