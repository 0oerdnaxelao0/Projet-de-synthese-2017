var searchData=
[
  ['forme',['Forme',['../class_forme.html#a4e221cd852b6ed7d43ccd017bff0ab25',1,'Forme::Forme(int couleur)'],['../class_forme.html#a85407d500482d96b8c910a8cc85a1aac',1,'Forme::Forme(const Forme &amp;f)']]],
  ['formecomposee',['FormeComposee',['../class_forme_composee.html#ade8e690b17bebc5531488cd3bb471cb4',1,'FormeComposee::FormeComposee(int couleur)'],['../class_forme_composee.html#ab782a3166271c1b7ce314d2ac740307d',1,'FormeComposee::FormeComposee(FormeComposee &amp;f)']]]
];
