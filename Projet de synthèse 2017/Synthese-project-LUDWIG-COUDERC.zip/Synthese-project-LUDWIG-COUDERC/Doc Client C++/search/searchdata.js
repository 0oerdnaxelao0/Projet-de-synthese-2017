var indexSectionsWithContent =
{
  0: "acdefghlmoprstv~",
  1: "cdefmpstv",
  2: "acdefghoprstv~",
  3: "lmr",
  4: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "related"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fonctions",
  3: "Variables",
  4: "Amis"
};

