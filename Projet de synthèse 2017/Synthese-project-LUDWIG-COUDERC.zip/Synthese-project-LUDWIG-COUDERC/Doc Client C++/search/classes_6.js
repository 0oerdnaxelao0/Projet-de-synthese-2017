var searchData=
[
  ['sauvegardevisiteur',['SauvegardeVisiteur',['../class_sauvegarde_visiteur.html',1,'']]],
  ['segment',['Segment',['../class_segment.html',1,'']]],
  ['singletonwinsock',['SingletonWinsock',['../class_singleton_winsock.html',1,'']]]
];
