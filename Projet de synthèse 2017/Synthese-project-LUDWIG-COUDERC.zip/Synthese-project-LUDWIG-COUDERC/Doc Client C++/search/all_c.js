var searchData=
[
  ['sauvegardevisiteur',['SauvegardeVisiteur',['../class_sauvegarde_visiteur.html',1,'SauvegardeVisiteur'],['../class_sauvegarde_visiteur.html#aa724a1868bb3d50a8be2884161bad4ea',1,'SauvegardeVisiteur::SauvegardeVisiteur()']]],
  ['segment',['Segment',['../class_segment.html',1,'Segment'],['../class_segment.html#a5d9a34fa521a2e6013b731704651e0ec',1,'Segment::Segment(int couleur, const Vecteur2D x, const Vecteur2D y)'],['../class_segment.html#abf7ca6b5b770672d9f9634ce10225baf',1,'Segment::Segment(const Segment &amp;s)']]],
  ['setcentre',['setCentre',['../class_cercle.html#ae97035df8faf98c134ddfecbdebca78c',1,'Cercle']]],
  ['setcouleur',['setCouleur',['../class_forme.html#aad6dc9d1318e452abad79061cd580dfb',1,'Forme']]],
  ['setrayon',['setRayon',['../class_cercle.html#ab166965772a83365ac4b7514c0089434',1,'Cercle']]],
  ['settabcotes',['setTabCotes',['../class_polygone.html#a194b6447be3c9d40175cfb4c0f7e5656',1,'Polygone']]],
  ['settabpts',['setTabPts',['../class_polygone.html#a730819f4bf5e1add1971b93af5218ceb',1,'Polygone']]],
  ['setx',['setX',['../class_vecteur2_d.html#a86c72e35bf635ace62cc8fd01c095ecd',1,'Vecteur2D']]],
  ['sety',['setY',['../class_vecteur2_d.html#a035a05db2e7fc5b9f886fa50517499b8',1,'Vecteur2D']]],
  ['singletonwinsock',['SingletonWinsock',['../class_singleton_winsock.html',1,'']]]
];
